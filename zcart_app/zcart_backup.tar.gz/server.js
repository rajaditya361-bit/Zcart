const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

const DB_FILE = path.join(__dirname, 'database.json');

function getDB() { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
function saveDB(data) { fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2)); }

app.get('/api/products', (req, res) => res.json(getDB().products));

// Add Product
app.post('/api/products', upload.single('imageFile'), (req, res) => {
    let db = getDB();
    let imagePath = req.file ? `/uploads/${req.file.filename}` : 'https://images.unsplash.com/photo-1559563362-c6731ba45855';
    let newProd = { 
        id: Date.now(), 
        name: req.body.name,
        category: req.body.category,
        price: Number(req.body.price), 
        origPrice: Number(req.body.origPrice),
        desc: req.body.desc,
        image: imagePath,
        badge: req.body.badge || 'ROSE'
    };
    db.products.push(newProd);
    saveDB(db);
    res.json({ success: true });
});

// Delete Product
app.delete('/api/products/:id', (req, res) => {
    let db = getDB();
    db.products = db.products.filter(p => p.id != req.params.id);
    saveDB(db);
    res.json({ success: true });
});

// Update Product
app.put('/api/products/:id', upload.single('imageFile'), (req, res) => {
    let db = getDB();
    let product = db.products.find(p => p.id == req.params.id);
    if(product) {
        product.name = req.body.name || product.name;
        product.category = req.body.category || product.category;
        product.price = req.body.price ? Number(req.body.price) : product.price;
        product.origPrice = req.body.origPrice ? Number(req.body.origPrice) : product.origPrice;
        product.desc = req.body.desc || product.desc;
        product.badge = req.body.badge || product.badge;
        if(req.file) {
            product.image = `/uploads/${req.file.filename}`;
        }
        saveDB(db);
        res.json({ success: true });
    } else {
        res.status(404).json({ success: false, message: 'Product not found' });
    }
});

app.get('/api/orders', (req, res) => res.json(getDB().orders));
app.post('/api/orders', (req, res) => {
    let db = getDB();
    let newOrder = {
        id: 'ORD' + Math.floor(100000 + Math.random() * 900000),
        ...req.body,
        date: new Date().toLocaleString('hi-IN'),
        status: 'Order Placed (पेंडिंग)'
    };
    db.orders.unshift(newOrder);
    saveDB(db);
    res.json({ success: true, order: newOrder });
});

app.post('/api/orders/status', (req, res) => {
    let db = getDB();
    let order = db.orders.find(o => o.id === req.body.orderId);
    if(order) {
        order.status = req.body.status;
        saveDB(db);
        res.json({ success: true });
    } else {
        res.status(404).json({ success: false });
    }
});

app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

app.listen(PORT, () => console.log(`ZCart Server running at http://localhost:${PORT}`));
